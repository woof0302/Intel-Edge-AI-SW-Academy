#include "device_driver.h"
#include "timer.h"

void TIMER2::Stopwatch_Start(void)
{
	TIM2->CR1 = (1<<4)|(1<<3);



}

unsigned int TIMER2::Stopwatch_Stop(void)
{



}

void TIMER2::Delay(int time)
{



}
