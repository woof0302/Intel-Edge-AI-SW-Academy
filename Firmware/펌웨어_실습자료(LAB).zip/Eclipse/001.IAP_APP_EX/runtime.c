#include "device_driver.h"

char * _sbrk(int inc)
{
	return (char *)0;
}
