#define SYSCLK	8000000
#define HCLK	SYSCLK
#define PCLK2	HCLK
#define PCLK1	HCLK
